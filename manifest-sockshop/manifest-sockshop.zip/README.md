# Manifests

Deploy the Sockshop Demo application on the OpenShift cluster in the `sockshop` project.

```
$ oc create -f .
```

